# ❄️ Snowball Package  

Snowball is a centralized, cross-platform package designed to generate **dbt-based code** seamlessly across multiple platforms such as **SQL Server, Snowflake, Databricks, Fabric**, and more.  
Whether the output format is **Spark SQL notebooks** or **plain SQL scripts**, Snowball bundles everything you need—including required libraries and dependencies—to connect with dbt scripts and generate platform-specific code versions.  

---

## 📚 Table of Contents  

- [Overview](#-overview)  
- [Requirements](#-requirements)  
- [Setup Instructions](#-setup-instructions)  
- [Features](#-features)  
- [Contributing](#-contributing)  
- [Upcoming Enhancements](#-upcoming-enhancements)  
- [License](#-license)  
- [Contact](#-contact)  

---

## 📖 Overview  

`dbt_runner` (part of the Snowball ecosystem) is a **Python-based automation tool** that:  
- Compiles and formats dbt projects.  
- Generates **PySpark notebooks** from compiled SQL files.  
- Packages dbt workflows into a ready-to-distribute archive.  

With Snowball, you can streamline **Analytics, Reporting, and R&D workflows** with minimal manual effort.  

---

## ⚙️ Requirements  

- **Python 3.7+**  
- Required dependencies (installed automatically with pip):  
  - `dbt-core`  
  - `sqlfluff`  
  - `nbformat`  
  - `pyspark`  

---

## 🚀 Setup Instructions  

### 1️⃣ Install the snowball git package using pip install command

Install directly from your organization's private Git repository:
```bash
pip install git+https://github.com/jmangroup/snowball.git
```

 - This installs the latest snowball_dbt code along with a prebuilt column_mapping.csv in your Downloads folder (used for mapping dimensions).

### 2️⃣ Trigger the main Snowball function by -

```bash
py
import snowball import snowball
snowball.main()
```

### 3️⃣ Configure Column Mapping & DBT Profile

 - Update column_mapping.csv with your required dimensions.
 - Edit your profiles.yml at:
 ```bash
 C:\Users\{UserName}\.dbt\profiles.yml
 ```

 This ensures Snowball connects to your target data platform for the snowball_dbt project.

### 4️⃣ Continue the process , Choose your data platform and your required version
 - Snowball will automatically generate a zipped project folder in your Downloads directory.

## ✨ Features

✅ Automated dependency installation.

✅ Programmatic execution of dbt models.

✅ SQLFluff formatting applied to compiled SQL.

✅ Transformation of dbt outputs into stored procedure-ready code.

✅ Automatic generation of PySpark notebooks.

✅ End-to-end project packaging into a ready-to-share archive.

## 🤝 Contributing

 - We welcome contributions!
 - Fork the repository.
 - Implement your enhancements.
 - Submit a pull request for review.

## 📅 Upcoming Features

* 🚀 One-click execution of Snowball workflows (remove multi-step triggers).
* ⚡ Optimized performance of the Snowball Python package.
* 📊 Extended support for additional data platforms.

## 📜 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## 📇 Contact

For any questions or issues, contact Vishal Verma <vishal.verma@jmangroup.com>.

